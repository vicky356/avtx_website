# AvTrix Website v3.5 Preview

## Connected loop and swept aircraft

- Added four visible copper junctions so every decision-stage card is physically connected to the engineering loop.
- Replaced the blocky aircraft with a slimmer swept silhouette inspired by the supplied flight-path reference.
- Removed the circular halo and detached exhaust marks so the loop itself reads as the aircraft's continuous trail.

## Unified aircraft loop

- Unified the visible engineering loop and the aircraft motion path so the aircraft now travels directly on the loop line.
- Repositioned the four stage cards outside the path to keep the aircraft visible without crossing the labels.

## Aircraft icon refinement

- Replaced the abstract aircraft mark with a recognisable top-down jet silhouette with a defined fuselage, swept wings and tailplane.
- Reduced the glow and added restrained exhaust trails so the aircraft reads as moving rather than suspended.
- Moved the aircraft onto an inset flight path so it remains visible instead of passing behind the four decision-stage cards.

## Aircraft-led engineering loop

- Replaced the directional arrow markers with a top-down aircraft icon that travels continuously around the engineering intelligence loop.
- Added a subtle dotted flight path and copper glow to make the motion readable without overpowering the four decision stages.
- Added a static aircraft fallback for visitors who prefer reduced motion.

## Engineering loop repair

- Replaced the percentage-positioned HTML oval with a responsive SVG diagram.
- Positioned all four stages explicitly: Technical evidence, Engineering reasoning, Decision output and Feedback.
- Added fixed view-box geometry so the loop preserves its proportions at desktop, tablet and mobile sizes.
- Added accessible title and description text for the diagram.
- Added directional flow arrows and a restrained animated evidence path; motion is disabled when reduced motion is preferred.

## Gradient refinement

- Added navy-to-slate depth gradients across the main surfaces.
- Added copper-to-champagne gradients to evidence metrics and calls to action.
- Added copper glow gradients to capability visuals and the engineering loop.
- Added subtle panel and footer gradients while preserving the approved AvTrix palette.
