# AvTrix website

Static marketing website for AvTrix, positioned as an engineering-led aviation procurement and fleet-intelligence business.

The current visual direction adopts selected structural ideas from the Valstream reference site—minimal navigation, large modern typography, dark data-led scenes and alternating capability demonstrations—while retaining the AvTrix identity, palette and narrative.

## Brand proposition

- Born from the Aviatrix. Built on engineering. Powered by intelligence.
- Engineering Insight. Smarter Sourcing. Stronger Fleets.
- Insight informed by experience.

## Information architecture

- `index.html` — brand proposition, capability overview and founder story
- `engineering.html` — engineering intelligence
- `procurement.html` — procurement and component intelligence
- `fleet.html` — fleet intelligence
- `about.html` — the Aviatrix story and founder perspective
- `alignment.html` — engagement models and the AvTrix method
- `services.html` — legacy URL forwarding to capabilities
- `partnership.html` — legacy URL forwarding to the engagement model

## Technical notes

- Buildless HTML, CSS and JavaScript
- Cloudflare Worker contact endpoint in `_worker.js`
- `RESEND_API_KEY` is required for contact-form delivery
- Shared navigation, modals and form handling are in `assets/site.js`

## Production identity note

The three-wing mark rendered in CSS is a digital placeholder reflecting the approved concept direction. Replace it with the final vector master artwork before production identity sign-off.
