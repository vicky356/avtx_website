# Changes in this working copy

## Forms
- All pages now use `assets/site.js` (shared modals + submission). about / services / fleet / alignment previously showed a fake "Message Received" and sent nothing.
- Nav "Request Quote" on every page opens the parts-request modal (as on the homepage).
- `_worker.js`: honeypot, email validation, length caps, control-character stripping, no CORS wildcard, provider errors logged not returned, 503 if `RESEND_API_KEY` is missing.

## Accuracy
- `alignment.html`: removed "< 15 Min", "99.8%" and "24/7/365"; replaced with claims the rest of the site already makes. Reworded the "predict" and "vetted against OEM specs and ADs" lines.
- `fleet.html`: footer WhatsApp/phone placeholder (+441234567890) replaced; WhatsApp links normalised to `wa.me/447999638984` sitewide.
- Founder wording changed to singular ("a Licensed Aircraft Engineer") on index and about.
- `partnership.html`: published client cap ("maximum of 10") softened to "a deliberately limited number".

## Positioning
- Homepage hero, problem strip, pillars, objective, services (four pillars: Fleet Reliability Intelligence, CAMO & Airworthiness Support, Engineering-Verified Procurement, Logistics & AOG Recovery), who-we-serve, titles, footer strapline and disclaimer.
- Footer disclaimer and airworthiness block now say "analysis, facilitation, sourcing and logistics coordination".
- Hawker tag now lists 750 / 800XP / 850XP / 900XP.
- `partnership.html`: Fleet Reliability Intelligence and CAMO Readiness & Transition added to the capability list.

## SEO
- Meta description, canonical and social-share tags on every page.

## Not changed
- Company number / registered office (needs the number), privacy notice, footer link consistency, teal vs copper accent decision.
