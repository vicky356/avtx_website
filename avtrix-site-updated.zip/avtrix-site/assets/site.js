/* AvTrix — shared site script
   Single source for navigation, contact / parts-request modals and form submission.
   Every page loads this file; the modal markup is injected here so it cannot drift per page. */
(function () {
  'use strict';

  var CONTACT_MODAL = [
    '<div id="contactModal" class="modal-overlay" role="dialog" aria-modal="true" aria-labelledby="contactModalTitle">',
    '  <div class="modal-content">',
    '    <button type="button" class="modal-close" aria-label="Close" onclick="closeModal()">&times;</button>',
    '    <div class="modal-header">',
    '      <div class="section-label">Direct Engagement</div>',
    '      <h2 id="contactModalTitle">Contact <span class="av">Av</span><span class="trix">Trix</span></h2>',
    '      <p>Tell us about your fleet and where the gaps are.</p>',
    '    </div>',
    '    <form class="contact-form" id="contact-form">',
    '      <div class="form-grid">',
    '        <input type="text" name="name" placeholder="Full Name" autocomplete="name" required maxlength="120">',
    '        <input type="email" name="email" placeholder="Email" autocomplete="email" required maxlength="160">',
    '      </div>',
    '      <input type="text" name="company" placeholder="Company / Operator" autocomplete="organization" maxlength="160">',
    '      <textarea name="message" placeholder="How can our technical team support you?" rows="5" required maxlength="4000"></textarea>',
    '      <input type="text" name="website" tabindex="-1" autocomplete="off" aria-hidden="true" style="position:absolute;left:-9999px;opacity:0;height:0;width:0;">',
    '      <button type="submit" class="btn-primary">Submit Inquiry &rarr;</button>',
    '    </form>',
    '    <div id="successMessage" style="display:none;text-align:center;padding:40px 0;">',
    '      <div style="font-size:48px;color:var(--teal);margin-bottom:16px;">&#10003;</div>',
    '      <h2 style="color:var(--white);margin-bottom:8px;">Message Received</h2>',
    '      <p style="color:var(--muted);">Thank you. We will review your enquiry and reply by email.</p>',
    '    </div>',
    '  </div>',
    '</div>'
  ].join('\n');

  var PARTS_MODAL = [
    '<div id="partsRequestModal" class="modal-overlay" role="dialog" aria-modal="true" aria-labelledby="partsModalTitle">',
    '  <div class="modal-content">',
    '    <button type="button" class="modal-close" aria-label="Close" onclick="closeModal()">&times;</button>',
    '    <div class="modal-header">',
    '      <div class="section-label">Procurement</div>',
    '      <h2 id="partsModalTitle">Request <span class="av">Av</span><span class="trix">Trix</span> Parts</h2>',
    '      <p>Precision sourcing with engineering-validated lead times.</p>',
    '    </div>',
    '    <form class="contact-form" id="parts-request-form">',
    '      <div class="form-grid">',
    '        <input type="text" name="name" placeholder="Full Name" autocomplete="name" required maxlength="120">',
    '        <input type="email" name="email" placeholder="Email" autocomplete="email" required maxlength="160">',
    '      </div>',
    '      <div class="form-grid" style="grid-template-columns:2fr 1fr;">',
    '        <input type="text" name="company" placeholder="Company / Organization" autocomplete="organization" required maxlength="160">',
    '        <input type="text" name="aog_status" placeholder="AOG Status (Yes/No)" maxlength="40">',
    '      </div>',
    '      <div class="form-grid" style="grid-template-columns:2fr 1fr;">',
    '        <input type="text" name="part_number" placeholder="Part Number (P/N)" required maxlength="120">',
    '        <input type="number" name="quantity" placeholder="Qty" min="1" required>',
    '      </div>',
    '      <textarea name="message" placeholder="Specify condition requirements (New, OH, SV) or additional technical notes..." rows="4" maxlength="4000"></textarea>',
    '      <input type="text" name="website" tabindex="-1" autocomplete="off" aria-hidden="true" style="position:absolute;left:-9999px;opacity:0;height:0;width:0;">',
    '      <button type="submit" class="btn-primary">Request Quote &rarr;</button>',
    '    </form>',
    '    <div id="partsSuccessMessage" style="display:none;text-align:center;padding:40px 0;">',
    '      <div style="font-size:48px;color:var(--teal);margin-bottom:16px;">&#10003;</div>',
    '      <h2 style="color:var(--white);margin-bottom:8px;">Request Submitted</h2>',
    '      <p style="color:var(--muted);">Thank you for contacting AvTrix. We will review your request and get back to you.</p>',
    '    </div>',
    '  </div>',
    '</div>'
  ].join('\n');

  function injectModals() {
    if (!document.getElementById('contactModal')) {
      document.body.insertAdjacentHTML('beforeend', CONTACT_MODAL);
    }
    if (!document.getElementById('partsRequestModal')) {
      document.body.insertAdjacentHTML('beforeend', PARTS_MODAL);
    }
  }

  // ---- Navigation -------------------------------------------------------
  window.toggleMenu = function () {
    var navLinks = document.getElementById('navLinks');
    var menuToggle = document.querySelector('.menu-toggle');
    if (navLinks) navLinks.classList.toggle('active');
    if (menuToggle) menuToggle.classList.toggle('active');
  };

  function bindNavClose() {
    document.querySelectorAll('.nav-links a').forEach(function (link) {
      link.addEventListener('click', function () {
        var navLinks = document.getElementById('navLinks');
        var menuToggle = document.querySelector('.menu-toggle');
        if (navLinks) navLinks.classList.remove('active');
        if (menuToggle) menuToggle.classList.remove('active');
      });
    });
  }

  // ---- Modals -----------------------------------------------------------
  function open(id) {
    var el = document.getElementById(id);
    if (!el) return;
    el.classList.add('active');
    document.body.style.overflow = 'hidden';
  }
  window.openModal = function () { open('contactModal'); };
  window.openPartsModal = function () { open('partsRequestModal'); };

  window.closeModal = function () {
    document.querySelectorAll('.modal-overlay').forEach(function (m) {
      m.classList.remove('active');
    });
    document.body.style.overflow = 'auto';

    // Reset forms after the fade-out animation
    setTimeout(function () {
      ['contact-form', 'parts-request-form'].forEach(function (id) {
        var f = document.getElementById(id);
        if (f) { f.style.display = 'flex'; f.style.opacity = '1'; f.reset(); }
      });
      ['successMessage', 'partsSuccessMessage'].forEach(function (id) {
        var s = document.getElementById(id);
        if (s) s.style.display = 'none';
      });
    }, 500);
  };

  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') window.closeModal();
  });
  window.addEventListener('click', function (e) {
    if (e.target.classList && e.target.classList.contains('modal-overlay')) window.closeModal();
  });

  // ---- Form submission --------------------------------------------------
  function getFormData(form) {
    var data = {};
    form.querySelectorAll('input, select, textarea').forEach(function (el) {
      if (el.name) data[el.name] = el.value;
    });
    return data;
  }

  async function handleFormSubmit(e, form, successEl, formType) {
    e.preventDefault();
    var btn = form.querySelector('button[type="submit"]');
    var original = btn ? btn.textContent : '';
    if (btn) { btn.disabled = true; btn.textContent = 'Sending...'; }

    var payload = Object.assign({ formType: formType }, getFormData(form));

    try {
      var res = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      if (!res.ok) throw new Error('Submission failed');

      form.style.transition = 'opacity 0.3s';
      form.style.opacity = '0';
      setTimeout(function () {
        form.style.display = 'none';
        successEl.style.display = 'block';
        successEl.style.opacity = '0';
        successEl.style.transition = 'opacity 0.5s';
        setTimeout(function () { successEl.style.opacity = '1'; }, 50);
      }, 300);
    } catch (err) {
      alert('Unable to submit your request. Please email info@avtrixservices.com directly.');
    } finally {
      if (btn) { btn.disabled = false; btn.textContent = original; }
    }
  }

  function bindForms() {
    var contactForm = document.getElementById('contact-form');
    var partsForm = document.getElementById('parts-request-form');
    if (contactForm) {
      contactForm.addEventListener('submit', function (e) {
        handleFormSubmit(e, contactForm, document.getElementById('successMessage'), 'General Contact');
      });
    }
    if (partsForm) {
      partsForm.addEventListener('submit', function (e) {
        handleFormSubmit(e, partsForm, document.getElementById('partsSuccessMessage'), 'Parts Request');
      });
    }
  }

  function init() {
    injectModals();
    bindNavClose();
    bindForms();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
