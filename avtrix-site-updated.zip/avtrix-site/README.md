# AvTrix website

Engineering-Led Fleet Intelligence for business and regional aviation.
Static site (HTML + one stylesheet + one script) served by a small Cloudflare Worker.

## Structure
```text
index.html        Home
about.html        About & approach
services.html     Four service pillars
fleet.html        Who we serve / aircraft supported
alignment.html    Integration model
partnership.html  Technical partnership (standalone page, own styles)
assets/style.css  Shared stylesheet (brand kit V2: slate / steel teal / muted copper)
assets/site.js    Shared script: nav, contact + parts-request modals, form submission
_worker.js        Serves assets; handles POST /api/contact (emails via Resend)
wrangler.jsonc    Cloudflare Worker config
```

## Forms
The contact and parts-request modals are injected by `assets/site.js` on every page, so they
cannot drift between pages. Submissions go to `POST /api/contact` (`_worker.js`), which validates the
payload, ignores honeypot (`website`) submissions, and emails `info@avtrixservices.com` via Resend.

Required Worker secret: `RESEND_API_KEY` (the sender domain avtrixservices.com must be verified in Resend).

## Before publishing (open items)
- Add the registered company name, number and registered office to the footer (a commented placeholder remains in each page).
- Add a short privacy notice and link it from the forms.
- Footer navigation links still differ slightly between pages.
