// AvTrix website worker — serves static assets and handles POST /api/contact (via Resend).
// Requires the secret RESEND_API_KEY to be set on the Cloudflare Worker.

const JSON_HEADERS = { "Content-Type": "application/json" };

const MAX_FIELD = 4000; // characters per field
const MAX_FIELDS = 20; // fields per submission
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

// Keys already used in the email header block; everything else is appended as "key: value".
const KNOWN_KEYS = new Set([
  "name",
  "email",
  "company",
  "message",
  "formType",
  "website", // honeypot
  "full_name",
  "professional_email",
  "company___operator",
  "how_can_our_technical_team_support_you_",
]);

const ALLOWED_FORM_TYPES = new Set(["General Contact", "Parts Request"]);

function json(body, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: JSON_HEADERS });
}

// Strip control characters and cap length. Newlines are kept in the body only.
function clean(value, { multiline = false } = {}) {
  let s = String(value ?? "").slice(0, MAX_FIELD);
  s = s.replace(multiline ? /[\u0000-\u0009\u000B\u000C\u000E-\u001F]/g : /[\u0000-\u001F]/g, " ");
  return s.trim();
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    if (url.pathname === "/api/contact") {
      // The site posts to its own origin, so no CORS headers are needed.
      if (request.method !== "POST") {
        return json({ error: "Method not allowed" }, 405);
      }

      let data;
      try {
        data = await request.json();
      } catch {
        return json({ error: "Invalid request" }, 400);
      }
      if (!data || typeof data !== "object" || Array.isArray(data)) {
        return json({ error: "Invalid request" }, 400);
      }
      if (Object.keys(data).length > MAX_FIELDS) {
        return json({ error: "Invalid request" }, 400);
      }

      // Honeypot: real visitors never fill this hidden field. Pretend success, send nothing.
      if (data.website) {
        return json({ success: true });
      }

      const senderName = clean(data.name || data.full_name) || "Website Visitor";
      const senderEmail = clean(data.email || data.professional_email);
      const senderCompany = clean(data.company || data.company___operator) || "N/A";
      const senderMessage =
        clean(data.message || data.how_can_our_technical_team_support_you_, { multiline: true }) ||
        "No message body provided.";
      const formType = ALLOWED_FORM_TYPES.has(data.formType) ? data.formType : "General Contact";

      if (!EMAIL_RE.test(senderEmail)) {
        return json({ error: "A valid email address is required" }, 400);
      }

      let bodyText = `Form Type: ${formType}\n`;
      bodyText += `Name: ${senderName}\n`;
      bodyText += `Email: ${senderEmail}\n`;
      bodyText += `Company: ${senderCompany}\n\n`;
      bodyText += `Message / Request Details:\n${senderMessage}\n`;

      // Extra fields (part number, quantity, AOG status, ...)
      for (const key of Object.keys(data)) {
        if (!KNOWN_KEYS.has(key)) {
          bodyText += `\n${clean(key)}: ${clean(data[key], { multiline: true })}`;
        }
      }

      if (!env.RESEND_API_KEY) {
        console.error("RESEND_API_KEY is not configured");
        return json({ error: "Service unavailable" }, 503);
      }

      try {
        const resendRes = await fetch("https://api.resend.com/emails", {
          method: "POST",
          headers: {
            Authorization: `Bearer ${env.RESEND_API_KEY}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            from: "AvTrix Website <noreply@avtrixservices.com>",
            to: ["info@avtrixservices.com"],
            reply_to: senderEmail,
            subject: `${formType} from ${senderName}`,
            text: bodyText,
          }),
        });

        if (!resendRes.ok) {
          // Log the provider's reason server-side; never return it to the browser.
          console.error("Resend error", resendRes.status, await resendRes.text());
          return json({ error: "Unable to send message" }, 502);
        }

        return json({ success: true });
      } catch (err) {
        console.error("Contact handler error", err && err.message);
        return json({ error: "Unable to send message" }, 500);
      }
    }

    return env.ASSETS ? env.ASSETS.fetch(request) : fetch(request);
  },
};
