/* Shared geometry keeps the aircraft, oval and four connectors attached. */
(function () {
  'use strict';
  const root = document.querySelector('.engineering-signature');
  if (!root) return;
  const loop = root.querySelector('.signature-loop');
  const svg = root.querySelector('.signature-track');
  const route = root.querySelector('.signature-route');
  const junctions = root.querySelector('.signature-junctions');
  const aircraft = root.querySelector('.signature-aircraft');
  const buttons = Array.from(root.querySelectorAll('.signature-stage'));
  const detail = root.querySelector('.signature-detail');
  const announcement = root.querySelector('.signature-announcement');
  const names = ['Technical evidence', 'Engineering reasoning', 'Decision output', 'Feedback'];
  const descriptions = [
    'Maintenance records, removals and component history.',
    'Evidence interpreted through engineering experience.',
    'Clear findings to support sourcing and fleet decisions.',
    'Operational outcomes feed the next engineering decision.'
  ];
  const preference = window.matchMedia('(prefers-reduced-motion: reduce)');
  let playing = !preference.matches, phase = 0, width = 400, radiusX = 140, last = 0, active = -1;
  let visible = true;
  const centerY = 115, radiusY = 53, cycleMs = 12000;

  function select(index, announce) {
    if (index !== active) {
      active = index;
      buttons.forEach((button, i) => button.setAttribute('aria-pressed', String(i === index)));
      detail.textContent = descriptions[index];
    }
    if (announce) announcement.textContent = names[index] + '. ' + descriptions[index];
  }
  function paint() {
    const t = -Math.PI * .75 + phase * Math.PI * 2;
    const x = width / 2 + radiusX * Math.cos(t), y = centerY + radiusY * Math.sin(t);
    const heading = Math.atan2(radiusY * Math.cos(t), -radiusX * Math.sin(t)) * 180 / Math.PI + 90;
    aircraft.style.left = x + 'px'; aircraft.style.top = y + 'px';
    aircraft.style.transform = 'translate(-50%, -50%) rotate(' + heading + 'deg)';
    select(Math.floor(((phase + .125) % 1) * 4));
  }
  function layout() {
    width = loop.clientWidth;
    if (!width) return;
    radiusX = width * .35;
    svg.setAttribute('viewBox', '0 0 ' + width + ' 230');
    route.setAttribute('d', `M${width / 2 - radiusX} 115 A${radiusX} 53 0 1 1 ${width / 2 + radiusX} 115 A${radiusX} 53 0 1 1 ${width / 2 - radiusX} 115`);
    junctions.replaceChildren();
    buttons.forEach((button, i) => {
      const t = -Math.PI * .75 + i * Math.PI / 2;
      const x = width / 2 + radiusX * Math.cos(t), y = centerY + radiusY * Math.sin(t);
      button.style.left = x + 'px'; button.style.top = (i < 2 ? 23 : 207) + 'px';
      const connector = document.createElementNS('http://www.w3.org/2000/svg', 'path');
      connector.setAttribute('d', `M${x} ${y} L${x} ${i < 2 ? 45 : 185}`);
      connector.setAttribute('fill', 'none');
      const dot = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
      dot.setAttribute('cx', x); dot.setAttribute('cy', y); dot.setAttribute('r', '3');
      junctions.append(connector, dot);
    });
    paint();
  }
  buttons.forEach((button, i) => button.addEventListener('click', function () {
    phase = i / 4; paint(); select(i, true);
  }));
  preference.addEventListener('change', function () {
    playing = !preference.matches;
  });
  new ResizeObserver(layout).observe(loop);
  if ('IntersectionObserver' in window) new IntersectionObserver(entries => {
    visible = entries[0].isIntersecting;
  }).observe(root);
  layout();
  function animate(now) {
    const delta = last ? Math.min(now - last, 100) : 0; last = now;
    if (playing && visible && !document.hidden) { phase = (phase + delta / cycleMs) % 1; paint(); }
    requestAnimationFrame(animate);
  }
  requestAnimationFrame(animate);
})();
