AVTRIX / ANIMATED SIGNATURE / 19 OCTOBER 2026

TWO FORMATS, SAME IDENTITY
The existing website aircraft silhouette and established AvTriX wordmark
are reused, with navy #1A1F25, copper #B8864F, champagne #CBA36A and cream
#FCFAF6. No replacement logo or aircraft icon has been invented.
The four stages are Technical evidence, Engineering reasoning, Decision
output and Feedback - not four new service offerings.

WEB / DIGITAL CARD
Open interactive-signature.html in a browser for the self-contained version.
Click or keyboard-activate a stage to stop at it and show its explanation.
Play/Pause controls the aircraft. Reduced-motion preferences start it paused.
The route, connectors and aircraft use the same coordinates and resize together.
web-embed-fragment.html is the integration source for one instance per page;
prefix its IDs if you need more than one instance. All imagery is embedded.
It makes no external requests, collects no data and has no tracking.
This is a brand-only signature component; add your name and contacts as real
text around it when using it as a digital business card.
The existing website has NOT been modified or published.

GMAIL
Start with AvTrix_Gmail_Animated_400x100.gif. It is a 12-second looping banner
with no personal details. The 600x100 version is a wider alternative.
The PNGs are static fallbacks and suitable for reduced-motion preferences.
Every frame contains the wordmark and all four stage labels, so the signature
still makes sense if a recipient sees only one frame.
The GIF is animated, not interactive: its stages do not have separate links,
hover details or a pause button. If desired, link the entire image to your
published website/digital card after you choose the destination URL.
No real website URL has been invented or embedded.

SETUP
On desktop Gmail, open Settings > See all settings > General > Signature.
Create or choose a signature, insert the 400x100 GIF with the image button,
then add your own name and contacts as normal text. Use Original size.
Save changes and send test emails to yourself and another email client.
If upload is unavailable, use a publicly accessible hosted image URL with
your administrator's approval. A local file path is not a public image URL.
Animation and images can be disabled by recipient preferences or software.
Use the static PNG if motion is inappropriate, and always keep essential
contact information as real text, not only in the image.
No Gmail account settings have been changed; delivery is not inbox-tested.

REFERENCE INFORMATION CHECKED 19 OCTOBER 2026
Google recommends signature imagery 70-100px high and 300-400px wide:
https://support.google.com/mail/answer/11468381?hl=en
Gmail signature setup:
https://support.google.com/mail/answer/8395?hl=en
Email GIF compatibility and partial-support notes:
https://www.caniemail.com/features/image-gif/

IDENTITY STATUS
The wordmark is the established guide-derived interim wordmark. This does not
constitute approval of a final Aviatrix symbol master. Any AI-generated logo
concepts still require approved vector master artwork before production.
